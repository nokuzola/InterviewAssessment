package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyFirstTest {
	public static void main (String[] args)
	{
		WebDriver driver = new ChromeDriver();
		//Navigate to global kinetic website
		
		driver.get("https://www.globalkinetic.com/");
		
		// Click on contact us link
		driver.findElement(By.xpath("//a[@href= \"#contact\"]")).click();
		// Fill in the form start with the title
		WebElement elementTitle = driver.findElement(By.id("title"));
		elementTitle.sendKeys("Enquire");
		// Enter name
		WebElement elementName = driver.findElement(By.id("name"));
		elementName.sendKeys("Zola");
		// Email address
		WebElement elementEmail = driver.findElement(By.id("email"));
		elementEmail.sendKeys("madaranokuzola@gmail.com");
		// And the message you want to send to Global Kinetic 
		WebElement elementMessage = driver.findElement(By.id("message"));
		elementMessage.sendKeys("Hello there!");
		// Click send button
		WebElement elementSendBtn = driver.findElement(By.xpath("//*[@id=\"submit\"]"));
		elementSendBtn.submit();
		
		
		
	}

}
