package io.appium.java_client.android;

import io.appium.java_client.android.AndroidDriver;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class AndroidDriver {
 
 private static RemoteWebDriver driver;
 public static void main(String[] args) throws MalformedURLException, InterruptedException {
 
	 //Set up appiumagainst a local application
 File appDir = new File(System.getProperty("user.dir"));
 File app = new File(appDir, "TestApp.app");
 
 DesiredCapabilities capabilities = new DesiredCapabilities();
 capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
 capabilities.setCapability("deviceName", "Micromax A311");
 capabilities.setCapability("platformVersion", "4.4.2");
 capabilities.setCapability("platformName", "Android");
 
 //Tell appium where the location of the app is
 capabilities.setCapability("app", app.getAbsolutePath());
 // Create remote web driver
  driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
 
 }
 
}